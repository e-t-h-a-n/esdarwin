//This dummy header file is created for mig to check when to call mig_strncpy_zerofill.
//Mig checks if this file is available to include and knows that Libsyscall has the new mig_strncpy_zerofill symbols to link to.
//Do not delete this file, mig will stop calling mig_strncpy_zerofill.

#ifndef __MACH_MIG_STRNCPY_ZEROFILL_SUPPORT__
#define __MACH_MIG_STRNCPY_ZEROFILL_SUPPORT__

#endif // __MACH_MIG_STRNCPY_ZEROFILL_SUPPORT__
